# Elevated-Transmission-Web

this is website for Elevated-Transmission 

Domain from GoDaddy 

Website host from Digital Ocean using nginx 
